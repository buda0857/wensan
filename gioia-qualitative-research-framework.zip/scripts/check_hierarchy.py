#!/usr/bin/env python3
"""
check_hierarchy.py
Analyzes hierarchy quality and methodological consistency

Usage:
  python check_hierarchy.py --structure-path /path/to/data-structure.json

支援中文（繁體）與英文混合資料結構。
"""

import argparse
import json
import math
import sys
from pathlib import Path
from typing import Dict, List, Any


# ── 英文：過度抽象的指標詞 ──────────────────────────────────────────────────
ABSTRACT_INDICATORS_EN = [
    "mechanism", "strategy", "construct", "dimension", "paradigm",
    "framework", "model", "theory", "dynamic", "process of",
    "enabling", "facilitating", "undermining", "leveraging"
]

# ── 英文：接地良好的指標詞（受訪者語言） ──────────────────────────────────
GROUNDED_INDICATORS_EN = [
    "i ", "we ", "they ", "my ", "our ", "their ",
    "said", "told", "felt", "wanted", "tried", "had to"
]

# ── 繁體中文：過度抽象的指標詞（適合二階主題或聚合維度，不適合一階概念） ──
ABSTRACT_INDICATORS_ZH = [
    "機制", "策略", "建構", "框架", "典範", "模型", "理論",
    "動態", "歷程", "過程", "促進", "阻礙", "賦能", "運用",
    "管理", "調適", "協商", "整合", "轉化", "建立", "維持",
]

# ── 繁體中文：接地良好的指標詞（受訪者第一人稱語言） ────────────────────
GROUNDED_INDICATORS_ZH = [
    "我", "我們", "他們", "她們", "你", "妳",
    "說", "覺得", "感覺", "想", "認為", "希望",
    "不得不", "只能", "沒辦法", "試著", "嘗試",
    "會", "要", "得", "就", "才", "啊", "嘛",
]


def is_abstract(concept_name: str, concept_def: str, informant_terms: List[str]) -> bool:
    """
    判斷一階概念是否過度抽象。
    同時檢查中英文指標詞，只要其中一種語言判定接地良好，就不視為過度抽象。
    """
    combined_text = (concept_name + " " + concept_def).lower()

    # 計算英文抽象分數
    abstract_score_en = sum(1 for w in ABSTRACT_INDICATORS_EN if w in combined_text)
    # 計算中文抽象分數（中文不需 lower()，直接比對）
    combined_text_zh = concept_name + concept_def
    abstract_score_zh = sum(1 for w in ABSTRACT_INDICATORS_ZH if w in combined_text_zh)

    abstract_score = abstract_score_en + abstract_score_zh

    if abstract_score <= 1:
        return False  # 抽象程度不足以觸發警告

    # 檢查 informant_terms 是否有接地的語言
    grounded_score = 0
    for term in informant_terms:
        term_lower = term.lower()
        grounded_score += sum(1 for w in GROUNDED_INDICATORS_EN if w in term_lower)
        grounded_score += sum(1 for w in GROUNDED_INDICATORS_ZH if w in term)

    # 同時檢查概念名稱本身是否含接地詞（中文一階概念常直接使用受訪者語言）
    grounded_score += sum(1 for w in GROUNDED_INDICATORS_ZH if w in concept_name)

    return grounded_score == 0


def analyze_hierarchy(structure: Dict[str, Any]) -> Dict[str, Any]:
    """Analyze hierarchy quality and methodological consistency."""
    analysis = {
        "overall_health": "good",
        "distribution": {
            "dimensions": [],
            "balance_score": 0.0
        },
        "abstraction_concerns": [],
        "quote_coverage": {
            "concepts_with_quotes": 0,
            "concepts_without_quotes": 0,
            "total_quotes": 0
        },
        "recommendations": []
    }

    if not structure.get("aggregate_dimensions"):
        analysis["overall_health"] = "error"
        analysis["recommendations"].append("未找到 aggregate_dimensions / No aggregate_dimensions found in structure")
        return analysis

    total_concepts = 0
    concepts_per_theme = []

    for dimension in structure["aggregate_dimensions"]:
        dim_analysis = {
            "id": dimension.get("id"),
            "name": dimension.get("name"),
            "theme_count": 0,
            "concept_count": 0
        }

        themes = dimension.get("second_order_themes")
        if not themes:
            dim_analysis["theme_count"] = 0
            analysis["distribution"]["dimensions"].append(dim_analysis)
            continue

        dim_analysis["theme_count"] = len(themes)

        # Check theme count per dimension
        if dim_analysis["theme_count"] < 2:
            analysis["recommendations"].append(
                f'維度「{dimension.get("name")}」只有 {dim_analysis["theme_count"]} 個主題——'
                f"請確認這是否應為維度，或應降級為主題"
            )
        elif dim_analysis["theme_count"] > 5:
            analysis["recommendations"].append(
                f'維度「{dimension.get("name")}」有 {dim_analysis["theme_count"]} 個主題——'
                f"考慮拆分為多個維度"
            )

        for theme in themes:
            concepts = theme.get("first_order_concepts", [])
            if not concepts:
                continue

            concept_count = len(concepts)
            dim_analysis["concept_count"] += concept_count
            total_concepts += concept_count
            concepts_per_theme.append(concept_count)

            # Check concept count per theme
            if concept_count < 2:
                analysis["recommendations"].append(
                    f'主題「{theme.get("name")}」只有 {concept_count} 個概念——'
                    f"可能需要更多實證基礎，或考慮與其他主題合併"
                )
            elif concept_count > 10:
                analysis["recommendations"].append(
                    f'主題「{theme.get("name")}」有 {concept_count} 個概念——'
                    f"考慮建立子主題或拆分"
                )

            # Analyze each concept
            for concept in concepts:
                # Check quote coverage
                quotes = concept.get("example_quotes", [])
                if quotes and len(quotes) > 0:
                    analysis["quote_coverage"]["concepts_with_quotes"] += 1
                    analysis["quote_coverage"]["total_quotes"] += len(quotes)
                else:
                    analysis["quote_coverage"]["concepts_without_quotes"] += 1

                # Check abstraction level（中英文雙語偵測）
                concept_name = concept.get("name") or ""
                concept_def = concept.get("definition") or ""
                informant_terms = concept.get("informant_terms", [])

                if is_abstract(concept_name, concept_def, informant_terms):
                    analysis["abstraction_concerns"].append({
                        "concept_id": concept.get("id"),
                        "concept_name": concept_name,
                        "concern": "一階概念可能過度抽象——應使用受訪者語言（1st-order concept may be too abstract）",
                        "suggestion": "考慮是否應升級為二階主題，或以受訪者實際用語重新命名"
                    })

        analysis["distribution"]["dimensions"].append(dim_analysis)

    # Calculate balance score (lower is better, 0 = perfectly balanced)
    if concepts_per_theme:
        avg = sum(concepts_per_theme) / len(concepts_per_theme)
        variance = sum((val - avg) ** 2 for val in concepts_per_theme) / len(concepts_per_theme)
        analysis["distribution"]["balance_score"] = round(math.sqrt(variance), 2)

        if analysis["distribution"]["balance_score"] > 3:
            analysis["recommendations"].append(
                f"各主題的概念數分佈不均（標準差：{analysis['distribution']['balance_score']}）——"
                f"部分主題可能需要合併或擴充"
            )

    # Overall health assessment
    total_with_quotes = analysis["quote_coverage"]["concepts_with_quotes"]
    total_without_quotes = analysis["quote_coverage"]["concepts_without_quotes"]
    total_concepts_quotes = total_with_quotes + total_without_quotes
    quote_coverage = total_with_quotes / total_concepts_quotes if total_concepts_quotes > 0 else 0

    if len(analysis["abstraction_concerns"]) > total_concepts * 0.2:
        analysis["overall_health"] = "needs_attention"
        analysis["recommendations"].append(
            "多個一階概念可能過度抽象，請審查是否充分植基於受訪者語言"
        )

    if quote_coverage < 0.5:
        analysis["overall_health"] = "needs_attention"
        analysis["recommendations"].append(
            f"只有 {quote_coverage * 100:.0f}% 的概念附有引言佐證——請補充更多實證基礎"
        )

    if not analysis["recommendations"]:
        analysis["recommendations"].append("結構在方法論上看起來健全！Structure looks methodologically sound!")

    return analysis


def main():
    parser = argparse.ArgumentParser(description="Check Gioia hierarchy quality（支援中英文）")
    parser.add_argument("--structure-path", required=True, help="Path to data structure JSON file")
    args = parser.parse_args()

    structure_path = Path(args.structure_path).resolve()

    # Path traversal protection - check for null bytes
    if "\x00" in str(structure_path):
        print(json.dumps({"success": False, "error": "Invalid path - null bytes detected"}, ensure_ascii=False))
        sys.exit(1)

    if not structure_path.exists():
        print(json.dumps({"success": False, "error": f"File not found: {args.structure_path}"}, ensure_ascii=False))
        sys.exit(1)

    try:
        with open(structure_path, "r", encoding="utf-8") as f:
            structure = json.load(f)
    except json.JSONDecodeError as e:
        print(json.dumps({"success": False, "error": f"Failed to parse JSON: {e}"}, ensure_ascii=False))
        sys.exit(1)
    except Exception as e:
        print(json.dumps({"success": False, "error": f"Failed to read file: {e}"}, ensure_ascii=False))
        sys.exit(1)

    analysis = analyze_hierarchy(structure)
    output = {"success": True, **analysis}
    # ensure_ascii=False 確保中文字正常輸出，不被轉成 \uXXXX
    print(json.dumps(output, indent=2, ensure_ascii=False))

    sys.exit(0 if analysis["overall_health"] != "error" else 1)


if __name__ == "__main__":
    main()
